# Crosswalk Signal Detection > 2024-04-21 8:42am
https://universe.roboflow.com/crosswalk-signal-detection/crosswalk-signal-detection

Provided by a Roboflow user
License: CC BY 4.0

